from flask import Flask, render_template, request
import mysql.connector



app = Flask(__name__)



# Replace with your MySQL database credentials
db_host = "localhost"
db_user = "root"
db_password = "password"
db_name = "ss"

# Function to establish a database connection
def create_connection():
    return mysql.connector.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_name
    )


# Route for the form page
@app.route("/", methods=["GET", "POST"])
def login_page():
    if request.method == "POST":
        # Get form data
        
        USN = request.form["USN"]
       
         # Convert the 'subscribe' checkbox value to BOOLEAN (0 or 1)
        #subscribe = 1 if "subscribe" in request.form else 0

        # Insert form data into the database
        connection = create_connection()
        cursor = connection.cursor()
        sql = "INSERT INTO login (USN) VALUES (%s)"
        values = (USN)
        cursor.execute(sql, values)
        connection.commit()
        connection.close()
        return render_template("frontpage.html")
        # return "Form submitted successfully!"
       
    return render_template("login.html")


@app.route("/registration", methods=["GET", "POST"])
def form_page():
    if request.method == "POST":
        # Get form data
        Name = request.form["Name"]
        USN = request.form["USN"]
        Password = request.form["Password"]
        Confirm_Password = request.form["Confirm_Password"]
        
        # Convert the 'subscribe' checkbox value to BOOLEAN (0 or 1)
        #subscribe = 1 if "subscribe" in request.form else 0

        # Insert form data into the database
        connection = create_connection()
        cursor = connection.cursor()
        sql = "INSERT INTO registration (Name,USN,Password,Confirm_Password) VALUES (%s, %s, %s, %s)"
        values = (Name,USN,Password,Confirm_Password)
        cursor.execute(sql, values)
        connection.commit()
        connection.close()
        return render_template("frontpage.html")
        # return "Form submitted successfully!"
          

    return render_template("registration.html")


if __name__ == "__main__":
    app.run()